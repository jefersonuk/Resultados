
export const RAW_NET_PROFIT_2025 = `Demonstrativo (Orçado X Realizado)->Nivel 3

Páginas:
Versões: ORCAMENTO 2025 OFICIAL
Ano: 2025
Estrutura Org. - Nivel 2: SUREC - SUPERINTENDENCIA REGIONAL CENTRO
Estrutura Org. - Nivel 3: DIGITAL
Estrutura Org. - Nivel 4: Total
Mês: Total


Nivel 1,Nivel 2,Estrutura - Nivel 3,Mês,Jan,Jan,Jan,Jan,Fev,Fev,Fev,Fev,Mar,Mar,Mar,Mar,Abr,Abr,Abr,Abr,Mai,Mai,Mai,Mai,Jun,Jun,Jun,Jun,Jul,Jul,Jul,Jul,Ago,Ago,Ago,Ago,Set,Set,Set,Set,Out,Out,Out,Out,Nov,Nov,Nov,Nov,Dez,Dez,Dez,Dez,Total,Total,Total,Total
 , , ,Métrica,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL, ,776.839,54,407.274,09,(369.565,45),(47,57),668.410,48,672.010,84,3.600,36,0,54,861.194,75,1.198.867,02,337.672,27,39,21,830.456,17,706.228,48,(124.227,69),(14,96),835.229,10,1.331.358,03,496.128,93,59,40,802.389,43,1.207.795,99,405.406,56,50,52,810.923,04,1.509.509,76,698.586,72,86,15,857.792,93,805.868,33,(51.924,60),(6,05),809.644,60,1.140.742,65,331.098,05,40,89,846.040,90,1.641.136,69,795.095,79,93,98,912.653,88,0,00,(912.653,88),(100,00),890.128,23,0,00,(890.128,23),(100,00),9.901.703,04,10.620.791,88,719.088,84,7,26
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,Total,, ,776.839,54,407.274,09,(369.565,45),(47,57),668.410,48,672.010,84,3.600,36,0,54,861.194,75,1.198.867,02,337.672,27,39,21,830.456,17,706.228,48,(124.227,69),(14,96),835.229,10,1.331.358,03,496.128,93,59,40,802.389,43,1.207.795,99,405.406,56,50,52,810.923,04,1.509.509,76,698.586,72,86,15,857.792,93,805.868,33,(51.924,60),(6,05),809.644,60,1.140.742,65,331.098,05,40,89,846.040,90,1.641.136,69,795.095,79,93,98,912.653,88,0,00,(912.653,88),(100,00),890.128,23,0,00,(890.128,23),(100,00),9.901.703,04,10.620.791,88,719.088,84,7,26`;

export const RAW_NET_PROFIT_2024 = `Demonstrativo (Orçado X Realizado)->Nivel 3

Páginas:
Versões: ORCAMENTO 2024 OFICIAL
Ano: 2024
Estrutura Org. - Nivel 2: SUREC - SUPERINTENDENCIA REGIONAL CENTRO
Estrutura Org. - Nivel 3: DIGITAL
Estrutura Org. - Nivel 4: Total
Mês: Total


Nivel 1,Nivel 2,Estrutura - Nivel 3,Mês,Jan,Jan,Jan,Jan,Fev,Fev,Fev,Fev,Mar,Mar,Mar,Mar,Abr,Abr,Abr,Abr,Mai,Mai,Mai,Mai,Jun,Jun,Jun,Jun,Jul,Jul,Jul,Jul,Ago,Ago,Ago,Ago,Set,Set,Set,Set,Out,Out,Out,Out,Nov,Nov,Nov,Nov,Dez,Dez,Dez,Dez,Total,Total,Total,Total
 , , ,Métrica,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL, ,679.590,12,694.239,85,14.649,73,2,16,671.202,08,638.523,05,(32.679,03),(4,87),755.889,88,704.861,02,(51.028,86),(6,75),692.847,46,834.530,20,141.682,74,20,45,744.914,18,1.000.929,14,256.014,96,34,37,756.195,84,729.001,22,(27.194,62),(3,60),761.354,98,683.460,25,(77.894,73),(10,23),786.823,56,848.377,94,61.554,38,7,82,801.482,05,865.021,38,63.539,33,7,93,805.166,74,1.054.894,89,249.728,15,31,02,852.118,40,1.052.809,28,200.690,88,23,55,855.303,00,854.239,53,(1.063,47),(0,12),9.162.888,30,9.960.887,75,797.999,45,8,71
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,Total,, ,679.590,12,694.239,85,14.649,73,2,16,671.202,08,638.523,05,(32.679,03),(4,87),755.889,88,704.861,02,(51.028,86),(6,75),692.847,46,834.530,20,141.682,74,20,45,744.914,18,1.000.929,14,256.014,96,34,37,756.195,84,729.001,22,(27.194,62),(3,60),761.354,98,683.460,25,(77.894,73),(10,23),786.823,56,848.377,94,61.554,38,7,82,801.482,05,865.021,38,63.539,33,7,93,805.166,74,1.054.894,89,249.728,15,31,02,852.118,40,1.052.809,28,200.690,88,23,55,855.303,00,854.239,53,(1.063,47),(0,12),9.162.888,30,9.960.887,75,797.999,45,8,71`;

export const RAW_NET_PROFIT_2023 = `Demonstrativo (Orçado X Realizado)->Nivel 3

Páginas:
Versões: ORCAMENTO 2023 OFICIAL
Ano: 2023
Estrutura Org. - Nivel 2: SUREC - SUPERINTENDENCIA REGIONAL CENTRO
Estrutura Org. - Nivel 3: DIGITAL
Estrutura Org. - Nivel 4: Total
Mês: Total


Nivel 1,Nivel 2,Estrutura - Nivel 3,Mês,Jan,Jan,Jan,Jan,Fev,Fev,Fev,Fev,Mar,Mar,Mar,Mar,Abr,Abr,Abr,Abr,Mai,Mai,Mai,Mai,Jun,Jun,Jun,Jun,Jul,Jul,Jul,Jul,Ago,Ago,Ago,Ago,Set,Set,Set,Set,Out,Out,Out,Out,Nov,Nov,Nov,Nov,Dez,Dez,Dez,Dez,Total,Total,Total,Total
 , , ,Métrica,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL, ,373.076,30,504.597,57,131.521,27,35,25,398.603,83,570.077,75,171.473,92,43,02,388.777,24,651.325,73,262.548,49,67,53,415.330,36,578.392,30,163.061,94,39,26,401.270,76,716.030,08,314.759,32,78,44,406.751,20,607.185,95,200.434,75,49,28,420.994,46,665.961,44,244.966,98,58,19,424.225,77,622.673,17,198.447,40,46,78,439.707,55,663.542,79,223.835,24,50,91,434.929,04,750.466,23,315.537,19,72,55,453.112,52,930.084,08,476.971,56,105,27,456.719,19,741.463,51,284.744,32,62,35,5.013.498,23,8.001.800,60,2.988.302,37,59,61
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,Total,, ,373.076,30,504.597,57,131.521,27,35,25,398.603,83,570.077,75,171.473,92,43,02,388.777,24,651.325,73,262.548,49,67,53,415.330,36,578.392,30,163.061,94,39,26,401.270,76,716.030,08,314.759,32,78,44,406.751,20,607.185,95,200.434,75,49,28,420.994,46,665.961,44,244.966,98,58,19,424.225,77,622.673,17,198.447,40,46,78,439.707,55,663.542,79,223.835,24,50,91,434.929,04,750.466,23,315.537,19,72,55,453.112,52,930.084,08,476.971,56,105,27,456.719,19,741.463,51,284.744,32,62,35,5.013.498,23,8.001.800,60,2.988.302,37,59,61`;

export const RAW_NET_PROFIT_2022 = `Demonstrativo (Orçado X Realizado)->Nivel 3

Páginas:
Versões: ORCAMENTO 2022 OFICIAL
Ano: 2022
Estrutura Org. - Nivel 2: SUREC - SUPERINTENDENCIA REGIONAL CENTRO
Estrutura Org. - Nivel 3: DIGITAL
Estrutura Org. - Nivel 4: Total
Mês: Total


Nivel 1,Nivel 2,Estrutura - Nivel 3,Mês,Jan,Jan,Jan,Jan,Fev,Fev,Fev,Fev,Mar,Mar,Mar,Mar,Abr,Abr,Abr,Abr,Mai,Mai,Mai,Mai,Jun,Jun,Jun,Jun,Jul,Jul,Jul,Jul,Ago,Ago,Ago,Ago,Set,Set,Set,Set,Out,Out,Out,Out,Nov,Nov,Nov,Nov,Dez,Dez,Dez,Dez,Total,Total,Total,Total
 , , ,Métrica,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL, ,226.196,93,254.434,30,28.237,37,12,48,209.605,99,266.881,53,57.275,54,27,33,233.411,82,297.213,11,63.801,29,27,33,222.754,86,328.781,02,106.026,16,47,60,243.467,57,256.879,97,13.412,40,5,51,233.670,55,348.434,65,114.764,11,49,11,240.192,63,361.529,02,121.336,39,50,52,247.037,15,369.376,89,122.339,74,49,52,234.810,43,377.475,33,142.664,90,60,76,243.887,82,500.354,48,256.466,66,105,16,239.673,97,469.874,43,230.200,46,96,05,249.237,65,474.407,46,225.169,82,90,34,2.823.947,36,4.305.642,20,1.481.694,84,52,47
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,Total,, ,226.196,93,254.434,30,28.237,37,12,48,209.605,99,266.881,53,57.275,54,27,33,233.411,82,297.213,11,63.801,29,27,33,222.754,86,328.781,02,106.026,16,47,60,243.467,57,256.879,97,13.412,40,5,51,233.670,55,348.434,65,114.764,11,49,11,240.192,63,361.529,02,121.336,39,50,52,247.037,15,369.376,89,122.339,74,49,52,234.810,43,377.475,33,142.664,90,60,76,243.887,82,500.354,48,256.466,66,105,16,239.673,97,469.874,43,230.200,46,96,05,249.237,65,474.407,46,225.169,82,90,34,2.823.947,36,4.305.642,20,1.481.694,84,52,47`;

export const RAW_NET_PROFIT_2021 = `Demonstrativo (Orçado X Realizado)->Nivel 3

Páginas:
Versões: ORCAMENTO 2021 OFICIAL
Ano: 2021
Estrutura Org. - Nivel 2: SUREC - SUPERINTENDENCIA REGIONAL CENTRO
Estrutura Org. - Nivel 3: DIGITAL
Estrutura Org. - Nivel 4: Total
Mês: Total


Nivel 1,Nivel 2,Estrutura - Nivel 3,Mês,Mar,Mar,Mar,Mar,Abr,Abr,Abr,Abr,Mai,Mai,Mai,Mai,Jun,Jun,Jun,Jun,Jul,Jul,Jul,Jul,Ago,Ago,Ago,Ago,Set,Set,Set,Set,Out,Out,Out,Out,Nov,Nov,Nov,Nov,Dez,Dez,Dez,Dez,Total,Total,Total,Total
 , , ,Métrica,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %,Valor Orçado,Valor Realizado,Dif. $,Dif. %
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL, ,250.575,87,259.427,98,8.852,11,3,53,190.014,92,199.422,50,9.407,58,4,95,202.463,11,212.599,57,10.136,46,5,01,194.517,76,208.506,98,13.989,22,7,19,195.552,00,215.279,34,19.727,34,10,09,214.611,12,233.663,80,19.052,68,8,88,226.296,05,234.962,88,8.666,83,3,83,230.041,28,286.201,39,56.160,11,24,41,234.215,67,230.240,73,(3.974,95),(1,70),258.092,54,396.093,62,138.001,08,53,47,2.196.380,31,2.476.398,78,280.018,47,12,75
LUCRO LÍQUIDO (EXCLUÍDA A REV) - GERENCIAL,Total,, ,250.575,87,259.427,98,8.852,11,3,53,190.014,92,199.422,50,9.407,58,4,95,202.463,11,212.599,57,10.136,46,5,01,194.517,76,208.506,98,13.989,22,7,19,195.552,00,215.279,34,19.727,34,10,09,214.611,12,233.663,80,19.052,68,8,88,226.296,05,234.962,88,8.666,83,3,83,230.041,28,286.201,39,56.160,11,24,41,234.215,67,230.240,73,(3.974,95),(1,70),258.092,54,396.093,62,138.001,08,53,47,2.196.380,31,2.476.398,78,280.018,47,12,75`;