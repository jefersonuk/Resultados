
import React from 'react';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import { KPIData } from '../types';

interface KPICardProps {
  data: KPIData;
  icon: React.ReactNode;
}

const KPICard: React.FC<KPICardProps> = ({ data, icon }) => {
  const isPositive = data.trend === 'up';
  const isNeutral = data.trend === 'neutral';
  
  // Cores Banestes: 
  // Positivo = Verde #00AB16 (Seta Ascendente)
  // Negativo = Rosa/Vermelho (Alinhado à paleta secundária ou alerta padrão)
  const trendColor = isPositive ? 'text-banestes-green' : isNeutral ? 'text-slate-400' : 'text-rose-500';
  const trendBg = isPositive ? 'bg-banestes-green/10 border-banestes-green/20' : isNeutral ? 'bg-slate-400/10 border-slate-400/20' : 'bg-rose-500/10 border-rose-500/20';
  
  return (
    <div className="bg-banestes-dark border border-banestes-blue/20 rounded-3xl p-6 transition-all duration-300 hover:border-banestes-blue hover:shadow-[0_0_30px_-10px_rgba(8,20,221,0.3)] group relative overflow-hidden">
      {/* Decorative accent on hover - Seta Ascendente Concept */}
      <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-banestes-blue/10 to-transparent rounded-bl-full transform translate-x-full group-hover:translate-x-0 transition-transform duration-500"></div>

      <div className="flex justify-between items-start mb-4 relative z-10">
        <div className="p-3.5 bg-banestes-bg rounded-2xl text-banestes-lightBlue border border-white/5 group-hover:text-white group-hover:bg-banestes-blue transition-colors duration-300 shadow-inner">
          {icon}
        </div>
        <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border ${trendBg} ${trendColor}`}>
          {isPositive && <ArrowUpRight size={14} strokeWidth={3} />}
          {!isPositive && !isNeutral && <ArrowDownRight size={14} strokeWidth={3} />}
          {isNeutral && <Minus size={14} strokeWidth={3} />}
          <span>{Math.abs(data.change).toLocaleString('pt-BR', { minimumFractionDigits: 4, maximumFractionDigits: 4 })}%</span>
        </div>
      </div>
      
      <div className="relative z-10">
        <h3 className="text-slate-400 text-xs font-brand font-bold tracking-wider uppercase mb-1">{data.label}</h3>
        <p className="text-3xl font-brand font-bold text-white tracking-tight">{data.value}</p>
        <div className="flex items-center gap-2 mt-2">
            <div className={`w-1 h-1 rounded-full ${isPositive ? 'bg-banestes-green' : 'bg-slate-500'}`}></div>
            <p className="text-banestes-lightBlue text-xs font-medium">{data.description}</p>
        </div>
      </div>
    </div>
  );
};

export default KPICard;
