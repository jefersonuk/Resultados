
import React, { useState, useMemo } from 'react';
import { Filter, Calendar, Layers } from 'lucide-react';
import { FinancialRecord } from '../types';
import { EvolutionChart } from './Charts';

interface CreditPortfolioTabProps {
  data: FinancialRecord[];
  availableProducts: string[];
}

const YEARS = [2021, 2022, 2023, 2024, 2025];
const MONTHS = [
  { value: 0, label: 'Todos' },
  { value: 1, label: 'Janeiro' },
  { value: 2, label: 'Fevereiro' },
  { value: 3, label: 'Março' },
  { value: 4, label: 'Abril' },
  { value: 5, label: 'Maio' },
  { value: 6, label: 'Junho' },
  { value: 7, label: 'Julho' },
  { value: 8, label: 'Agosto' },
  { value: 9, label: 'Setembro' },
  { value: 10, label: 'Outubro' },
  { value: 11, label: 'Novembro' },
  { value: 12, label: 'Dezembro' },
];

const toTitleCase = (str: string) => {
  return str.replace(
    /\w\S*/g,
    (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
  );
};

const CreditPortfolioTab: React.FC<CreditPortfolioTabProps> = ({ data, availableProducts }) => {
  const [selectedYear, setSelectedYear] = useState<number | 'Todos'>('Todos'); 
  const [selectedMonth, setSelectedMonth] = useState<number>(0);
  const [selectedProduct, setSelectedProduct] = useState<string>('Todos');

  // Normalizador para remover acentos e garantir comparação robusta
  const normalizeText = (text: string) => {
    return text
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();
  };

  // Filtragem e Agregação de Dados
  const { saldoData, rendaData } = useMemo(() => {
    let filtered = data;

    if (selectedYear !== 'Todos') {
      filtered = filtered.filter(d => d.year === selectedYear);
    }

    if (selectedMonth !== 0) {
      filtered = filtered.filter(d => d.month === selectedMonth);
    }

    if (selectedProduct !== 'Todos') {
      const target = normalizeText(selectedProduct);
      filtered = filtered.filter(d => normalizeText(d.product) === target);
    }

    // Agrupar por data para o gráfico
    const groupByDate = (records: FinancialRecord[], type: 'saldo' | 'renda') => {
      const typeRecords = records.filter(r => r.type === type);
      const map = new Map<string, { orcado: number; realizado: number; date: string; sortId: number }>();

      typeRecords.forEach(r => {
        // Chave de agrupamento: Mês/Ano (ex: Jan/21)
        const key = `${r.monthLabel}/${r.year.toString().slice(-2)}`; 
        const sortKey = r.year * 100 + r.month; // Para ordenação correta

        if (!map.has(key)) {
          map.set(key, { orcado: 0, realizado: 0, date: key, sortId: sortKey });
        }
        
        const entry = map.get(key)!;
        entry.orcado += r.orcado;
        entry.realizado += r.realizado;
      });

      return Array.from(map.values())
        .sort((a, b) => a.sortId - b.sortId)
        .map(({ date, orcado, realizado }) => ({ date, orcado, realizado, churnRate: 0 }));
    };

    return {
      saldoData: groupByDate(filtered, 'saldo'),
      rendaData: groupByDate(filtered, 'renda')
    };
  }, [data, selectedYear, selectedMonth, selectedProduct]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Filtros */}
      <div className="bg-banestes-dark border border-banestes-blue/20 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center gap-2 mb-4 text-banestes-green font-brand font-bold text-sm uppercase tracking-wider">
          <Filter size={16} />
          Filtros da Carteira
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Ano */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 font-bold ml-1">Ano de Referência</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-banestes-lightBlue w-4 h-4 pointer-events-none" />
              <select 
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value === 'Todos' ? 'Todos' : Number(e.target.value))}
                className="w-full bg-[#1a1e33] border border-banestes-lightBlue/30 rounded-xl py-2.5 pl-10 pr-8 text-sm text-white focus:border-banestes-blue focus:ring-1 focus:ring-banestes-blue outline-none appearance-none cursor-pointer hover:bg-[#252a40] transition-colors"
                style={{ colorScheme: 'dark' }}
              >
                <option value="Todos">Histórico Completo (2021-2025)</option>
                {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
              </div>
            </div>
          </div>

          {/* Mês */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 font-bold ml-1">Mês de Referência</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-banestes-lightBlue w-4 h-4 pointer-events-none" />
              <select 
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(Number(e.target.value))}
                className="w-full bg-[#1a1e33] border border-banestes-lightBlue/30 rounded-xl py-2.5 pl-10 pr-8 text-sm text-white focus:border-banestes-blue focus:ring-1 focus:ring-banestes-blue outline-none appearance-none cursor-pointer hover:bg-[#252a40] transition-colors"
                style={{ colorScheme: 'dark' }}
              >
                {MONTHS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
              </div>
            </div>
          </div>

          {/* Produto */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 font-bold ml-1">Produto</label>
            <div className="relative">
              <Layers className="absolute left-3 top-1/2 -translate-y-1/2 text-banestes-lightBlue w-4 h-4 pointer-events-none" />
              <select 
                value={selectedProduct}
                onChange={(e) => setSelectedProduct(e.target.value)}
                className="w-full bg-[#1a1e33] border border-banestes-lightBlue/30 rounded-xl py-2.5 pl-10 pr-8 text-sm text-white focus:border-banestes-blue focus:ring-1 focus:ring-banestes-blue outline-none appearance-none cursor-pointer hover:bg-[#252a40] transition-colors"
                style={{ colorScheme: 'dark' }}
              >
                <option value="Todos">Todos</option>
                {availableProducts.map(p => <option key={p} value={p}>{toTitleCase(p)}</option>)}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        
        {/* Gráfico de Saldo */}
        <div className="bg-banestes-dark border border-banestes-blue/20 rounded-3xl p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-banestes-blue/5 rounded-full blur-[80px] -mr-10 -mt-10 group-hover:bg-banestes-blue/10 transition-colors duration-500"></div>
          
          <div className="flex flex-col mb-8 relative z-10 gap-2">
            <h3 className="text-xl font-brand font-bold text-white">Evolução de Saldo</h3>
            <p className="text-xs text-slate-400">Comparativo Orçado vs Realizado (Milhões)</p>
          </div>
          
          <div className="h-[400px]">
             {saldoData.length > 0 ? (
                <EvolutionChart data={saldoData} />
             ) : (
                <div className="h-full flex items-center justify-center text-slate-500 font-medium">Sem dados para os filtros selecionados</div>
             )}
          </div>
        </div>

        {/* Gráfico de Rendas */}
        <div className="bg-banestes-dark border border-banestes-blue/20 rounded-3xl p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-banestes-pink/5 rounded-full blur-[80px] -mr-10 -mt-10 group-hover:bg-banestes-pink/10 transition-colors duration-500"></div>
          
          <div className="flex flex-col mb-8 relative z-10 gap-2">
            <h3 className="text-xl font-brand font-bold text-white">Evolução de Rendas</h3>
            <p className="text-xs text-slate-400">Comparativo Orçado vs Realizado (Milhões)</p>
          </div>
          
          <div className="h-[400px]">
             {rendaData.length > 0 ? (
                <EvolutionChart data={rendaData} />
             ) : (
                <div className="h-full flex items-center justify-center text-slate-500 font-medium">Sem dados para os filtros selecionados</div>
             )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default CreditPortfolioTab;
