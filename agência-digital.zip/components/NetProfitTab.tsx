
import React, { useState, useMemo } from 'react';
import { Filter, Calendar, TrendingUp, Target, CheckCircle2, AlertCircle } from 'lucide-react';
import { 
  ComposedChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell
} from 'recharts';
import { EvolutionChart } from './Charts';
import { RAW_DATA_2021, RAW_DATA_2022, RAW_DATA_2023, RAW_DATA_2024, RAW_DATA_2025 } from '../data/rawFinancialData';
import { RAW_TREASURY_2021, RAW_TREASURY_2022, RAW_TREASURY_2023, RAW_TREASURY_2024, RAW_TREASURY_2025 } from '../data/rawTreasuryData';
import { RAW_SERVICE_2021, RAW_SERVICE_2022, RAW_SERVICE_2023, RAW_SERVICE_2024, RAW_SERVICE_2025 } from '../data/rawServiceData';
import { RAW_PROVISION_2021, RAW_PROVISION_2022, RAW_PROVISION_2023, RAW_PROVISION_2024, RAW_PROVISION_2025 } from '../data/rawProvisionData';
import { RAW_ADMIN_EXPENSES_2021, RAW_ADMIN_EXPENSES_2022, RAW_ADMIN_EXPENSES_2023, RAW_ADMIN_EXPENSES_2024, RAW_ADMIN_EXPENSES_2025 } from '../data/rawAdministrativeExpensesData';
import { RAW_NET_PROFIT_2021, RAW_NET_PROFIT_2022, RAW_NET_PROFIT_2023, RAW_NET_PROFIT_2024, RAW_NET_PROFIT_2025 } from '../data/rawNetProfitData';

// === TYPES ===
interface ProfitRecord {
    year: number;
    month: number;
    monthLabel: string;
    category: 'Credit' | 'Treasury' | 'Services' | 'Provision' | 'Admin' | 'NetProfit';
    orcado: number;
    realizado: number;
}

// === CONSTANTS & HELPERS ===
const YEARS = [2021, 2022, 2023, 2024, 2025];
const MONTH_MAP: { [key: string]: number } = {
  'Jan': 1, 'Fev': 2, 'Mar': 3, 'Abr': 4, 'Mai': 5, 'Jun': 6,
  'Jul': 7, 'Ago': 8, 'Set': 9, 'Out': 10, 'Nov': 11, 'Dez': 12
};
const MONTHS = [
  { value: 0, label: 'Todos' },
  { value: 1, label: 'Janeiro' },
  { value: 2, label: 'Fevereiro' },
  { value: 3, label: 'Março' },
  { value: 4, label: 'Abril' },
  { value: 5, label: 'Maio' },
  { value: 6, label: 'Junho' },
  { value: 7, label: 'Julho' },
  { value: 8, label: 'Agosto' },
  { value: 9, label: 'Setembro' },
  { value: 10, label: 'Outubro' },
  { value: 11, label: 'Novembro' },
  { value: 12, label: 'Dezembro' },
];
const MONTH_LABELS = ['', 'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

const parseBrazilianNumber = (val: string): number => {
  if (!val) return 0;
  let cleanVal = val.trim();
  let isNegative = false;
  if (cleanVal.startsWith('(') && cleanVal.endsWith(')')) {
    isNegative = true;
    cleanVal = cleanVal.slice(1, -1);
  }
  cleanVal = cleanVal.replace(/\./g, '').replace(',', '.');
  let num = parseFloat(cleanVal);
  if (isNaN(num)) return 0;
  return isNegative ? -num : num;
};

// === PARSER ===
const parseSourceData = (
    sourceMap: Record<number, string>, 
    category: 'Credit' | 'Treasury' | 'Services' | 'Provision' | 'Admin' | 'NetProfit',
    filterFn: (parts: string[]) => boolean
): ProfitRecord[] => {
    const records: ProfitRecord[] = [];

    Object.entries(sourceMap).forEach(([yearStr, rawText]) => {
        const year = parseInt(yearStr);
        const lines = rawText.split('\n');
        
        let headerIndex = -1;
        for(let i=0; i<lines.length; i++) {
            if(lines[i].startsWith('Nivel 1')) {
                headerIndex = i;
                break;
            }
        }
        if (headerIndex === -1) return;

        const headerLine = lines[headerIndex];
        const headerParts = headerLine.split(',');
        const monthBlockMap: { blockIndex: number, month: number }[] = [];
        
        let currentBlock = 0;
        const startColIndex = 4;

        for (let i = startColIndex; i < headerParts.length; i += 4) {
            const monthName = headerParts[i].trim();
            if (monthName === 'Total') break;
            if (MONTH_MAP[monthName]) {
                monthBlockMap.push({
                    blockIndex: currentBlock,
                    month: MONTH_MAP[monthName]
                });
            }
            currentBlock++;
        }

        for (let i = headerIndex + 1; i < lines.length; i++) {
            const line = lines[i];
            if (!line.trim()) continue;
            
            const parts = line.split(',');
            if (!filterFn(parts)) continue;

            monthBlockMap.forEach(({ blockIndex, month }) => {
                const realBaseIndex = startColIndex + (blockIndex * 8);
                if (realBaseIndex + 3 >= parts.length) return;

                const orcadoFull = parts[realBaseIndex] + ',' + parts[realBaseIndex+1];
                const realizadoFull = parts[realBaseIndex+2] + ',' + parts[realBaseIndex+3];

                const orcado = parseBrazilianNumber(orcadoFull);
                const realizado = parseBrazilianNumber(realizadoFull);

                if (orcado !== 0 || realizado !== 0) {
                     records.push({
                         year,
                         month,
                         monthLabel: MONTH_LABELS[month],
                         category,
                         orcado: orcado, // Raw Value (Reais)
                         realizado: realizado // Raw Value (Reais)
                     });
                }
            });
        }
    });
    return records;
};

const NetProfitTab: React.FC = () => {
  const [selectedYear, setSelectedYear] = useState<number | 'Todos'>('Todos'); 
  const [selectedMonth, setSelectedMonth] = useState<number>(0);

  // === DATA AGGREGATION ===
  const { netProfitData, operationalBreakdown } = useMemo(() => {
    // 1. Credit Income (Rendas)
    const creditData = parseSourceData({
        2021: RAW_DATA_2021, 2022: RAW_DATA_2022, 2023: RAW_DATA_2023, 2024: RAW_DATA_2024, 2025: RAW_DATA_2025
    }, 'Credit', (parts) => {
        return parts[0]?.startsWith('RENDAS') && parts[1]?.trim() === 'Total';
    });

    // 2. Treasury Result
    const treasuryData = parseSourceData({
        2021: RAW_TREASURY_2021, 2022: RAW_TREASURY_2022, 2023: RAW_TREASURY_2023, 2024: RAW_TREASURY_2024, 2025: RAW_TREASURY_2025
    }, 'Treasury', (parts) => {
        return parts[0]?.startsWith('RECEITAS') && parts[1]?.trim() === 'Total';
    });

    // 3. Service Income
    const serviceData = parseSourceData({
        2021: RAW_SERVICE_2021, 2022: RAW_SERVICE_2022, 2023: RAW_SERVICE_2023, 2024: RAW_SERVICE_2024, 2025: RAW_SERVICE_2025
    }, 'Services', (parts) => {
        return parts[0]?.startsWith('OUTRAS RECEITAS') && parts[1]?.trim() === 'Total';
    });

    // 4. Provision Expenses (PDD)
    const provisionData = parseSourceData({
        2021: RAW_PROVISION_2021, 2022: RAW_PROVISION_2022, 2023: RAW_PROVISION_2023, 2024: RAW_PROVISION_2024, 2025: RAW_PROVISION_2025
    }, 'Provision', (parts) => {
        return parts[0]?.startsWith('DESPESAS') && parts[1]?.trim() === 'Total';
    });

    // 5. Admin Expenses
    const adminData = parseSourceData({
        2021: RAW_ADMIN_EXPENSES_2021, 2022: RAW_ADMIN_EXPENSES_2022, 2023: RAW_ADMIN_EXPENSES_2023, 2024: RAW_ADMIN_EXPENSES_2024, 2025: RAW_ADMIN_EXPENSES_2025
    }, 'Admin', (parts) => {
        return parts[0]?.startsWith('OUTRAS RECEITAS') && parts[1]?.trim() === 'Total';
    });

    // 6. Official Net Profit Data
    const officialProfitData = parseSourceData({
        2021: RAW_NET_PROFIT_2021, 2022: RAW_NET_PROFIT_2022, 2023: RAW_NET_PROFIT_2023, 2024: RAW_NET_PROFIT_2024, 2025: RAW_NET_PROFIT_2025
    }, 'NetProfit', (parts) => {
        return parts[0]?.startsWith('LUCRO LÍQUIDO') && parts[1]?.trim() === 'Total';
    });

    return {
        netProfitData: officialProfitData,
        operationalBreakdown: [...creditData, ...treasuryData, ...serviceData, ...provisionData, ...adminData]
    };
  }, []);

  // === FILTERING & CALCULATIONS ===
  const { chartData, breakdownChartData, totalRealizado, totalOrcado, isProfitPositive, realizationRate } = useMemo(() => {
    let filteredProfit = netProfitData;
    let filteredBreakdown = operationalBreakdown;

    if (selectedYear !== 'Todos') {
      filteredProfit = filteredProfit.filter(d => d.year === selectedYear);
      filteredBreakdown = filteredBreakdown.filter(d => d.year === selectedYear);
    }

    if (selectedMonth !== 0) {
      filteredProfit = filteredProfit.filter(d => d.month === selectedMonth);
      filteredBreakdown = filteredBreakdown.filter(d => d.month === selectedMonth);
    }

    // --- Traffic Light Totals (Raw) ---
    let tRealizado = 0;
    let tOrcado = 0;

    filteredProfit.forEach(r => {
        tRealizado += r.realizado;
        tOrcado += r.orcado;
    });

    const profitPositive = tRealizado >= tOrcado;
    const rate = tOrcado !== 0 ? (tRealizado / tOrcado) * 100 : 0;

    // --- Chart Data (Millions) ---
    const mapMonthly = new Map<string, { orcado: number; realizado: number; date: string; sortId: number }>();

    filteredProfit.forEach(r => {
        const key = `${r.monthLabel}/${r.year.toString().slice(-2)}`; 
        const sortKey = r.year * 100 + r.month;

        if (!mapMonthly.has(key)) {
            mapMonthly.set(key, { orcado: 0, realizado: 0, date: key, sortId: sortKey });
        }
        const entry = mapMonthly.get(key)!;
        entry.orcado += r.orcado;
        entry.realizado += r.realizado;
    });

    const evolutionData = Array.from(mapMonthly.values())
        .sort((a, b) => a.sortId - b.sortId)
        .map(({ date, orcado, realizado }) => ({ 
            date, 
            orcado: orcado / 1000000, 
            realizado: realizado / 1000000 
        }));

    // --- Breakdown Data (Millions) ---
    const breakdownMap = new Map<string, number>();
    breakdownMap.set('Credit', 0);
    breakdownMap.set('Treasury', 0);
    breakdownMap.set('Services', 0);
    breakdownMap.set('Provision', 0);
    breakdownMap.set('Admin', 0);

    filteredBreakdown.forEach(r => {
        const currentVal = breakdownMap.get(r.category) || 0;
        breakdownMap.set(r.category, currentVal + r.realizado);
    });

    const breakdownData = [
        { name: 'Rendas Crédito', value: (breakdownMap.get('Credit') || 0) / 1000000 },
        { name: 'Tesouraria', value: (breakdownMap.get('Treasury') || 0) / 1000000 }, 
        { name: 'Serviços', value: (breakdownMap.get('Services') || 0) / 1000000 },
        { name: 'Provisão (PDD)', value: (breakdownMap.get('Provision') || 0) / 1000000 },
        { name: 'Desp. Adm.', value: (breakdownMap.get('Admin') || 0) / 1000000 },
    ];

    return {
      chartData: evolutionData,
      breakdownChartData: breakdownData,
      totalRealizado: tRealizado,
      totalOrcado: tOrcado,
      isProfitPositive: profitPositive,
      realizationRate: rate
    };
  }, [netProfitData, operationalBreakdown, selectedYear, selectedMonth]);

  // Custom Tooltip for Breakdown
  const BreakdownTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-banestes-dark border border-banestes-blue/30 p-3 rounded-xl shadow-xl backdrop-blur-md">
          <p className="text-white font-brand font-bold mb-1">{data.name}</p>
          <span className={`font-mono font-bold ${data.value >= 0 ? 'text-banestes-green' : 'text-banestes-pink'}`}>
            R$ {data.value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} M
          </span>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Filtros */}
      <div className="bg-banestes-dark border border-banestes-blue/20 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center gap-2 mb-4 text-banestes-green font-brand font-bold text-sm uppercase tracking-wider">
          <Filter size={16} />
          Filtros de Resultado
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Ano */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 font-bold ml-1">Ano de Referência</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-banestes-lightBlue w-4 h-4 pointer-events-none" />
              <select 
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value === 'Todos' ? 'Todos' : Number(e.target.value))}
                className="w-full bg-[#1a1e33] border border-banestes-lightBlue/30 rounded-xl py-2.5 pl-10 pr-8 text-sm text-white focus:border-banestes-blue focus:ring-1 focus:ring-banestes-blue outline-none appearance-none cursor-pointer hover:bg-[#252a40] transition-colors"
                style={{ colorScheme: 'dark' }}
              >
                <option value="Todos">Histórico Completo (2021-2025)</option>
                {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
              </div>
            </div>
          </div>

          {/* Mês */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 font-bold ml-1">Mês de Referência</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-banestes-lightBlue w-4 h-4 pointer-events-none" />
              <select 
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(Number(e.target.value))}
                className="w-full bg-[#1a1e33] border border-banestes-lightBlue/30 rounded-xl py-2.5 pl-10 pr-8 text-sm text-white focus:border-banestes-blue focus:ring-1 focus:ring-banestes-blue outline-none appearance-none cursor-pointer hover:bg-[#252a40] transition-colors"
                style={{ colorScheme: 'dark' }}
              >
                {MONTHS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Traffic Light Cards (Farol) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card Realizado */}
          <div className={`relative p-6 rounded-3xl border transition-all duration-300 overflow-hidden group ${
              isProfitPositive 
                ? 'bg-banestes-green/10 border-banestes-green/30 hover:border-banestes-green shadow-[0_0_20px_-5px_rgba(0,171,22,0.2)]' 
                : 'bg-banestes-pink/10 border-banestes-pink/30 hover:border-banestes-pink shadow-[0_0_20px_-5px_rgba(204,83,139,0.2)]'
          }`}>
              <div className="absolute top-0 right-0 p-6 opacity-20">
                  {isProfitPositive ? <CheckCircle2 size={80} className="text-banestes-green" /> : <AlertCircle size={80} className="text-banestes-pink" />}
              </div>
              <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-2">
                      <div className={`p-2 rounded-lg ${isProfitPositive ? 'bg-banestes-green text-white' : 'bg-banestes-pink text-white'}`}>
                          <TrendingUp size={20} />
                      </div>
                      <span className={`text-sm font-bold uppercase tracking-wider ${isProfitPositive ? 'text-banestes-green' : 'text-banestes-pink'}`}>
                          Resultado Realizado
                      </span>
                  </div>
                  <h3 className="text-4xl font-brand font-bold text-white mb-1">
                      R$ {totalRealizado.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
                  </h3>
                  <div className="flex items-center gap-2 mt-4">
                      <div className={`w-2 h-2 rounded-full ${isProfitPositive ? 'bg-banestes-green animate-pulse' : 'bg-banestes-pink animate-pulse'}`}></div>
                      <p className="text-slate-400 text-xs font-medium">
                          {isProfitPositive ? 'Acima da Meta' : 'Abaixo da Meta'} ({realizationRate.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}% do Orçado)
                      </p>
                  </div>
              </div>
          </div>

          {/* Card Orçado */}
          <div className="relative p-6 rounded-3xl border border-banestes-blue/20 bg-banestes-dark hover:border-banestes-blue transition-all duration-300 overflow-hidden group shadow-lg">
              <div className="absolute top-0 right-0 p-6 opacity-10">
                  <Target size={80} className="text-banestes-lightBlue" />
              </div>
              <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 rounded-lg bg-banestes-blue/20 text-banestes-lightBlue border border-banestes-blue/30">
                          <Target size={20} />
                      </div>
                      <span className="text-sm font-bold uppercase tracking-wider text-banestes-lightBlue">
                          Meta Orçamentária
                      </span>
                  </div>
                  <h3 className="text-4xl font-brand font-bold text-white mb-1">
                      R$ {totalOrcado.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
                  </h3>
                  <div className="flex items-center gap-2 mt-4">
                      <div className="w-2 h-2 rounded-full bg-banestes-blue"></div>
                      <p className="text-slate-400 text-xs font-medium">
                          Planejamento {selectedYear === 'Todos' ? 'Acumulado' : selectedYear}
                      </p>
                  </div>
              </div>
          </div>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Gráfico de Evolução */}
        <div className="xl:col-span-2 bg-banestes-dark border border-banestes-blue/20 rounded-3xl p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-banestes-blue/5 rounded-full blur-[80px] -mr-10 -mt-10 group-hover:bg-banestes-blue/10 transition-colors duration-500"></div>
          
          <div className="flex flex-col mb-8 relative z-10 gap-2">
            <h3 className="text-xl font-brand font-bold text-white">Evolução do Lucro Líquido</h3>
            <p className="text-xs text-slate-400">Comparativo Mensal Orçado vs Realizado (Milhões)</p>
          </div>
          
          <div className="h-[400px] w-full">
             {chartData.length > 0 ? (
               <EvolutionChart data={chartData} />
             ) : (
                <div className="h-full flex items-center justify-center text-slate-500 font-medium">Sem dados para os filtros selecionados</div>
             )}
          </div>
        </div>

        {/* Gráfico de Composição (Breakdown) */}
        <div className="xl:col-span-1 bg-banestes-dark border border-banestes-blue/20 rounded-3xl p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-banestes-pink/5 rounded-full blur-[80px] -mr-10 -mt-10 group-hover:bg-banestes-pink/10 transition-colors duration-500"></div>
          
          <div className="flex flex-col mb-8 relative z-10 gap-2">
            <h3 className="text-xl font-brand font-bold text-white">Composição Operacional</h3>
            <p className="text-xs text-slate-400">Impacto por Vertical (Acumulado)</p>
          </div>
          
          <div className="h-[400px] w-full">
             <ResponsiveContainer width="100%" height="100%">
               <ComposedChart data={breakdownChartData} layout="vertical" margin={{ top: 0, right: 30, left: 20, bottom: 0 }}>
                 <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#3d619e" opacity={0.1} />
                 <XAxis type="number" hide />
                 <YAxis 
                   dataKey="name" 
                   type="category" 
                   tick={{ fill: '#fff', fontSize: 11, fontFamily: 'Montserrat', fontWeight: 600 }} 
                   width={100}
                   tickLine={false}
                   axisLine={false}
                 />
                 <Tooltip content={<BreakdownTooltip />} cursor={{ fill: 'transparent' }} />
                 <Bar dataKey="value" barSize={30} radius={[0, 4, 4, 0]}>
                    {breakdownChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.value >= 0 ? '#00AB16' : '#cc538b'} />
                    ))}
                 </Bar>
               </ComposedChart>
             </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
};

export default NetProfitTab;
