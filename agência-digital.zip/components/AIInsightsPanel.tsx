import React from 'react';
import { Sparkles, Lightbulb, TrendingUp, AlertTriangle, ArrowRight } from 'lucide-react';
import { AIInsight } from '../types';

interface AIInsightsPanelProps {
  insights: AIInsight[];
  isLoading: boolean;
}

const AIInsightsPanel: React.FC<AIInsightsPanelProps> = ({ insights, isLoading }) => {
  if (isLoading) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 space-y-4 animate-pulse">
        <div className="relative">
             <div className="absolute inset-0 bg-banestes-blue blur-xl opacity-20 rounded-full"></div>
             <Sparkles className="w-10 h-10 text-banestes-blue animate-spin-slow relative z-10" />
        </div>
        <p className="text-banestes-lightBlue text-sm font-bold font-brand">Banestes IA analisando carteira...</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3 mb-8 pb-4 border-b border-banestes-blue/20">
        <div className="p-2.5 bg-banestes-blue/20 rounded-xl border border-banestes-blue/30 shadow-[0_0_15px_-5px_#0814DD]">
          <Sparkles className="w-5 h-5 text-banestes-blue" />
        </div>
        <div>
           <h2 className="text-xl font-brand font-bold text-white leading-tight">Inteligência de Dados</h2>
           <p className="text-[10px] text-slate-400 font-medium">Powered by Gemini</p>
        </div>
      </div>

      <div className="grid gap-5">
        {insights.map((insight, index) => {
          let Icon = Lightbulb;
          // Colors mapped to Banestes Identity
          // Positive: Green #00AB16
          // Neutral: Blue #4e8dcc
          // Negative: Muted Red/Pink #cc538b
          
          let containerClass = 'border-banestes-lightBlue/30 bg-banestes-lightBlue/5';
          let iconClass = 'text-banestes-lightBlue bg-banestes-lightBlue/10';
          let titleClass = 'text-white';
          
          if (insight.sentiment === 'positive') {
            Icon = TrendingUp;
            containerClass = 'border-banestes-green/40 bg-banestes-green/5 shadow-[0_4px_20px_-12px_rgba(0,171,22,0.3)]';
            iconClass = 'text-banestes-green bg-banestes-green/10';
            titleClass = 'text-banestes-green';
          } else if (insight.sentiment === 'negative') {
            Icon = AlertTriangle;
            containerClass = 'border-banestes-pink/40 bg-banestes-pink/5';
            iconClass = 'text-banestes-pink bg-banestes-pink/10';
            titleClass = 'text-banestes-pink';
          }

          return (
            <div key={index} className={`p-5 rounded-2xl border ${containerClass} transition-all duration-300 hover:-translate-y-1 hover:bg-opacity-20`}>
              <div className="flex items-start gap-4">
                <div className={`mt-1 p-2.5 rounded-xl ${iconClass}`}>
                  <Icon size={18} strokeWidth={2.5} />
                </div>
                <div className="flex-1">
                  <h4 className={`font-brand font-bold text-sm mb-2 ${titleClass}`}>{insight.title}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed mb-4 border-l-2 border-white/10 pl-3 font-medium">
                    {insight.summary}
                  </p>
                  <div className="flex flex-col gap-2 mt-2 bg-banestes-bg/60 p-3 rounded-lg border border-white/5">
                    <div className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-banestes-blue"></span>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-banestes-lightBlue">Ação Recomendada</span>
                    </div>
                    <div className="flex items-start gap-2">
                        <ArrowRight size={12} className="mt-0.5 text-slate-500 min-w-[12px]"/>
                        <span className="text-xs font-semibold text-white">
                        {insight.actionableItem}
                        </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AIInsightsPanel;