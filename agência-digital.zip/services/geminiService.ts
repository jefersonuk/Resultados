
import { GoogleGenAI, Type } from "@google/genai";
import { MonthlyMetric, AIInsight } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateDataStory = async (data: MonthlyMetric[]): Promise<AIInsight[]> => {
  try {
    // Pegar os últimos 6 meses para análise de tendência recente + comparação anual
    const recentData = data.slice(-6); 
    const dataContext = JSON.stringify(recentData);

    const prompt = `
      Atue como um Especialista em Data Storytelling Financeiro para o Banco Banestes (Agência Digital).
      Analise os seguintes dados recentes (Orçado vs Realizado): ${dataContext}.
      
      Gere 3 insights narrativos curtos e impactantes.
      1. Desempenho da Carteira (Realizado vs Meta/Orçado).
      2. Tendência de Crescimento (Comparativo mês a mês).
      3. Qualidade/Inadimplência (Churn Rate neste contexto é inadimplência).
      
      Para cada insight, forneça:
      - Título curto.
      - Resumo narrativo (o que os dados dizem, use termos financeiros).
      - Item acionável (o que fazer a respeito).
      - Sentimento (positive, negative, neutral).
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING },
              actionableItem: { type: Type.STRING },
              sentiment: { type: Type.STRING, enum: ["positive", "negative", "neutral"] }
            },
            required: ["title", "summary", "actionableItem", "sentiment"]
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as AIInsight[];
    }
    return [];
  } catch (error) {
    console.error("Failed to generate AI insights:", error);
    return [
      {
        title: "Análise Indisponível",
        summary: "Não foi possível conectar à IA para gerar o storytelling dos dados no momento.",
        actionableItem: "Verifique sua chave de API ou conexão.",
        sentiment: "neutral"
      }
    ];
  }
};
