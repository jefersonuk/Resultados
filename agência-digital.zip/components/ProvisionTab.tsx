
import React, { useState, useMemo } from 'react';
import { Filter, Calendar, Layers } from 'lucide-react';
import { EvolutionChart } from './Charts';
import { RAW_PROVISION_2021, RAW_PROVISION_2022, RAW_PROVISION_2023, RAW_PROVISION_2024, RAW_PROVISION_2025 } from '../data/rawProvisionData';

interface ProvisionRecord {
    year: number;
    month: number;
    monthLabel: string;
    product: string;
    orcado: number;
    realizado: number;
}

const YEARS = [2021, 2022, 2023, 2024, 2025];
const MONTH_MAP: { [key: string]: number } = {
  'Jan': 1, 'Fev': 2, 'Mar': 3, 'Abr': 4, 'Mai': 5, 'Jun': 6,
  'Jul': 7, 'Ago': 8, 'Set': 9, 'Out': 10, 'Nov': 11, 'Dez': 12
};
const MONTHS = [
  { value: 0, label: 'Todos' },
  { value: 1, label: 'Janeiro' },
  { value: 2, label: 'Fevereiro' },
  { value: 3, label: 'Março' },
  { value: 4, label: 'Abril' },
  { value: 5, label: 'Maio' },
  { value: 6, label: 'Junho' },
  { value: 7, label: 'Julho' },
  { value: 8, label: 'Agosto' },
  { value: 9, label: 'Setembro' },
  { value: 10, label: 'Outubro' },
  { value: 11, label: 'Novembro' },
  { value: 12, label: 'Dezembro' },
];

const MONTH_LABELS = ['', 'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

const toTitleCase = (str: string) => {
  return str.replace(
    /\w\S*/g,
    (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
  );
};

const normalizeText = (text: string) => {
    return text
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();
};

const parseBrazilianNumber = (val: string): number => {
  if (!val) return 0;
  let cleanVal = val.trim();
  let isNegative = false;
  if (cleanVal.startsWith('(') && cleanVal.endsWith(')')) {
    isNegative = true;
    cleanVal = cleanVal.slice(1, -1);
  }
  cleanVal = cleanVal.replace(/\./g, '').replace(',', '.');
  let num = parseFloat(cleanVal);
  if (isNaN(num)) return 0;
  return isNegative ? -num : num;
};

const parseProvisionData = (): { records: ProvisionRecord[], products: string[] } => {
    const records: ProvisionRecord[] = [];
    const productsSet = new Set<string>();
    
    const rawDataMap = {
        2021: RAW_PROVISION_2021,
        2022: RAW_PROVISION_2022,
        2023: RAW_PROVISION_2023,
        2024: RAW_PROVISION_2024,
        2025: RAW_PROVISION_2025
    };

    Object.entries(rawDataMap).forEach(([yearStr, rawText]) => {
        const year = parseInt(yearStr);
        const lines = rawText.split('\n');
        
        let headerIndex = -1;
        for(let i=0; i<lines.length; i++) {
            if(lines[i].startsWith('Nivel 1')) {
                headerIndex = i;
                break;
            }
        }
        if (headerIndex === -1) return;

        const headerLine = lines[headerIndex];
        const headerParts = headerLine.split(',');
        const monthBlockMap: { blockIndex: number, month: number }[] = [];
        
        let currentBlock = 0;
        // Identificar colunas de meses no cabeçalho
        // In Provision data headers, 'Jan' starts at index 4 (Nivel 1, Nivel 2, Nivel 3, Mes, Jan...)
        for (let i = 4; i < headerParts.length; i += 4) {
            const monthName = headerParts[i].trim();
            if (monthName === 'Total') break;
            if (MONTH_MAP[monthName]) {
                monthBlockMap.push({
                    blockIndex: currentBlock,
                    month: MONTH_MAP[monthName]
                });
            }
            currentBlock++;
        }

        // Processar Linhas de Dados
        for (let i = headerIndex + 1; i < lines.length; i++) {
            const line = lines[i];
            if (!line.trim()) continue;
            
            const parts = line.split(',');
            // New structure starts with DESPESAS DA INTERMEDIACAO FINANCEIRA
            if (!parts[0]?.startsWith('DESPESAS DA INTERMEDIACAO FINANCEIRA')) continue;

            // Identificar Produto e Offset de Coluna
            // Total rows: Nivel 2 is 'Total' (index 1)
            const isTotalRow = parts[1]?.trim() === 'Total';
            
            // If total row, product name is 'Total'. 
            // If regular row, product name is usually in Nivel 3 (index 2).
            const productRaw = isTotalRow ? 'Total' : parts[2]?.trim();
            
            if (!productRaw) continue;
            if (!isTotalRow) productsSet.add(productRaw);

            // Ajuste fino de offset baseado na análise dos dados brutos:
            // Regular: [0]DESPESAS, [1]RESULTADO, [2]PRODUTO, [3]Space, [4]DataStart... (Offset 4)
            // Total: [0]DESPESAS, [1]Total, [2]Empty, [3]Space, [4]DataStart... (Offset 4)
            // Both seem to have offset 4 in this dataset.
            const baseOffset = 4;

            monthBlockMap.forEach(({ blockIndex, month }) => {
                // Cada bloco de mês tem 4 valores: Orçado, Realizado, Dif$, Dif%
                // Como os números brasileiros usam vírgula e o CSV não tem aspas, cada número ocupa 2 índices.
                // 4 valores * 2 parts = 8 índices por bloco.
                const realBaseIndex = baseOffset + (blockIndex * 8);
                
                if (realBaseIndex + 3 >= parts.length) return;

                // Reconstroi os números
                const orcadoFull = parts[realBaseIndex] + ',' + parts[realBaseIndex+1];
                const realizadoFull = parts[realBaseIndex+2] + ',' + parts[realBaseIndex+3];

                const orcado = parseBrazilianNumber(orcadoFull);
                const realizado = parseBrazilianNumber(realizadoFull);

                // Só adiciona se tiver dados relevantes
                if (orcado !== 0 || realizado !== 0) {
                     records.push({
                         year,
                         month,
                         monthLabel: MONTH_LABELS[month],
                         product: productRaw,
                         // Converter para Milhões, mas manter o sinal (Expense/Reversal)
                         orcado: orcado, 
                         realizado: realizado
                     });
                }
            });
        }
    });
    
    return { 
        records, 
        products: Array.from(productsSet).sort() 
    };
};

const ProvisionTab: React.FC = () => {
  const [selectedYear, setSelectedYear] = useState<number | 'Todos'>('Todos'); 
  const [selectedMonth, setSelectedMonth] = useState<number>(0);
  const [selectedProduct, setSelectedProduct] = useState<string>('Todos');

  // Load Data
  const { records: allData, products: availableProducts } = useMemo(() => parseProvisionData(), []);

  // Filter and Aggregate Data
  const { resultData } = useMemo(() => {
    let filtered = allData;

    if (selectedYear !== 'Todos') {
      filtered = filtered.filter(d => d.year === selectedYear);
    }

    if (selectedMonth !== 0) {
      filtered = filtered.filter(d => d.month === selectedMonth);
    }

    // Filtragem de Produtos:
    // Se 'Todos' for selecionado, usamos APENAS as linhas de 'Total' para evitar contagem dupla
    if (selectedProduct === 'Todos') {
      filtered = filtered.filter(d => d.product === 'Total');
    } else {
      const target = normalizeText(selectedProduct);
      filtered = filtered.filter(d => normalizeText(d.product) === target);
    }

    // Agrupar por data (Mensal)
    const groupByDate = (records: ProvisionRecord[]) => {
        const map = new Map<string, { orcado: number; realizado: number; date: string; sortId: number }>();

        records.forEach(r => {
            const key = `${r.monthLabel}/${r.year.toString().slice(-2)}`; 
            const sortKey = r.year * 100 + r.month;

            if (!map.has(key)) {
                map.set(key, { orcado: 0, realizado: 0, date: key, sortId: sortKey });
            }
            const entry = map.get(key)!;
            entry.orcado += r.orcado;
            entry.realizado += r.realizado;
        });

        // Converter para Milhões para o gráfico (dividindo por 1.000.000)
        return Array.from(map.values())
            .sort((a, b) => a.sortId - b.sortId)
            .map(({ date, orcado, realizado }) => ({ 
                date, 
                orcado: orcado / 1000000, 
                realizado: realizado / 1000000, 
                churnRate: 0 
            }));
    };

    return {
      resultData: groupByDate(filtered)
    };
  }, [allData, selectedYear, selectedMonth, selectedProduct]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Filtros */}
      <div className="bg-banestes-dark border border-banestes-blue/20 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center gap-2 mb-4 text-banestes-green font-brand font-bold text-sm uppercase tracking-wider">
          <Filter size={16} />
          Filtros de PDD
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Ano */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 font-bold ml-1">Ano de Referência</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-banestes-lightBlue w-4 h-4 pointer-events-none" />
              <select 
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value === 'Todos' ? 'Todos' : Number(e.target.value))}
                className="w-full bg-[#1a1e33] border border-banestes-lightBlue/30 rounded-xl py-2.5 pl-10 pr-8 text-sm text-white focus:border-banestes-blue focus:ring-1 focus:ring-banestes-blue outline-none appearance-none cursor-pointer hover:bg-[#252a40] transition-colors"
                style={{ colorScheme: 'dark' }}
              >
                <option value="Todos">Histórico Completo (2021-2025)</option>
                {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
              </div>
            </div>
          </div>

          {/* Mês */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 font-bold ml-1">Mês de Referência</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-banestes-lightBlue w-4 h-4 pointer-events-none" />
              <select 
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(Number(e.target.value))}
                className="w-full bg-[#1a1e33] border border-banestes-lightBlue/30 rounded-xl py-2.5 pl-10 pr-8 text-sm text-white focus:border-banestes-blue focus:ring-1 focus:ring-banestes-blue outline-none appearance-none cursor-pointer hover:bg-[#252a40] transition-colors"
                style={{ colorScheme: 'dark' }}
              >
                {MONTHS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
              </div>
            </div>
          </div>

          {/* Produto */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 font-bold ml-1">Produto</label>
            <div className="relative">
              <Layers className="absolute left-3 top-1/2 -translate-y-1/2 text-banestes-lightBlue w-4 h-4 pointer-events-none" />
              <select 
                value={selectedProduct}
                onChange={(e) => setSelectedProduct(e.target.value)}
                className="w-full bg-[#1a1e33] border border-banestes-lightBlue/30 rounded-xl py-2.5 pl-10 pr-8 text-sm text-white focus:border-banestes-blue focus:ring-1 focus:ring-banestes-blue outline-none appearance-none cursor-pointer hover:bg-[#252a40] transition-colors"
                style={{ colorScheme: 'dark' }}
              >
                <option value="Todos">Todos</option>
                {availableProducts.map(p => <option key={p} value={p}>{toTitleCase(p)}</option>)}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Gráficos */}
      <div className="w-full">
        
        {/* Gráfico de Resultado de PDD */}
        <div className="bg-banestes-dark border border-banestes-blue/20 rounded-3xl p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-banestes-pink/5 rounded-full blur-[80px] -mr-10 -mt-10 group-hover:bg-banestes-pink/10 transition-colors duration-500"></div>
          
          <div className="flex flex-col mb-8 relative z-10 gap-2">
            <h3 className="text-xl font-brand font-bold text-white">Resultado de PDD</h3>
            <p className="text-xs text-slate-400">Orçado vs Realizado (Milhões) - Valores Positivos indicam Reversão/Lucro, Negativos indicam Despesa</p>
          </div>
          
          <div className="h-[500px] w-full">
             {resultData.length > 0 ? (
                <EvolutionChart data={resultData} />
             ) : (
                <div className="h-full flex items-center justify-center text-slate-500 font-medium">Sem dados para os filtros selecionados</div>
             )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default ProvisionTab;
