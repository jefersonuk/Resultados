
import React from 'react';
import { 
  ComposedChart, Line, Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, Legend 
} from 'recharts';
import { MonthlyMetric } from '../types';

// Custom Tooltip for better UX
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-banestes-dark border border-banestes-blue/30 p-4 rounded-xl shadow-2xl shadow-black/80 backdrop-blur-md min-w-[200px]">
        <p className="text-white font-brand font-bold mb-3 border-b border-white/10 pb-2">{label}</p>
        {payload.map((entry: any, index: number) => {
          const isRealizado = entry.dataKey === 'realizado';
          return (
            <div key={index} className="flex items-center justify-between gap-4 text-sm my-1.5">
              <div className="flex items-center gap-2">
                <div 
                  className={`w-2 h-2 rounded-full ${isRealizado ? 'animate-pulse' : ''}`} 
                  style={{ backgroundColor: entry.color }} 
                />
                <span className="text-slate-300 capitalize font-medium">
                  {entry.name}:
                </span>
              </div>
              <span className={`font-bold font-mono ${isRealizado ? 'text-white text-base' : 'text-slate-400'}`}>
                R$ {entry.value.toLocaleString('pt-BR', { minimumFractionDigits: 4, maximumFractionDigits: 4 })} M
              </span>
            </div>
          );
        })}
      </div>
    );
  }
  return null;
};

interface EvolutionChartProps {
  data: MonthlyMetric[];
}

export const EvolutionChart: React.FC<EvolutionChartProps> = ({ data }) => {
  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 20, right: 20, left: -10, bottom: 0 }}>
          <defs>
            <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity={0.8}/>
              <stop offset="100%" stopColor="#FFFFFF" stopOpacity={0.1}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#3d619e" vertical={false} opacity={0.1} />
          <XAxis 
            dataKey="date" 
            stroke="#4e8dcc" 
            tick={{ fill: '#4e8dcc', fontSize: 10, fontFamily: 'Montserrat', fontWeight: 500 }} 
            tickLine={false}
            axisLine={false}
            dy={10}
            minTickGap={30} // Evita sobreposição de datas
          />
          <YAxis 
            stroke="#4e8dcc" 
            tick={{ fill: '#4e8dcc', fontSize: 10, fontFamily: 'Montserrat', fontWeight: 500 }} 
            tickFormatter={(value) => `R$${value}M`}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: '#0814DD', opacity: 0.05 }} />
          
          {/* Orçado (Barras) - Alterado para Branco */}
          <Bar 
            dataKey="orcado" 
            name="Orçado" 
            barSize={12}
            fill="url(#barGradient)"
            stroke="#FFFFFF"
            strokeOpacity={0.5}
            radius={[2, 2, 0, 0]}
          />

          {/* Realizado (Linha) - Destaque em Verde (Crescimento) ou Azul Neon */}
          <Line 
            type="monotone" 
            dataKey="realizado" 
            name="Realizado" 
            stroke="#00AB16" 
            strokeWidth={3}
            dot={false}
            activeDot={{ r: 6, fill: "#00AB16", stroke: "#fff", strokeWidth: 2 }}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};

export const BudgetRealizedChart: React.FC<EvolutionChartProps> = ({ data }) => {
  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 20, right: 20, left: -10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#3d619e" vertical={false} opacity={0.1} />
          <XAxis 
            dataKey="date" 
            stroke="#4e8dcc" 
            tick={{ fill: '#4e8dcc', fontSize: 10, fontFamily: 'Montserrat', fontWeight: 500 }} 
            tickLine={false}
            axisLine={false}
            dy={10}
          />
          <YAxis 
            stroke="#4e8dcc" 
            tick={{ fill: '#4e8dcc', fontSize: 10, fontFamily: 'Montserrat', fontWeight: 500 }} 
            tickFormatter={(value) => `R$${value}M`}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: '#0814DD', opacity: 0.05 }} />
          <Legend wrapperStyle={{ paddingTop: '20px' }} />
          
          <Bar 
            dataKey="orcado" 
            name="Orçado" 
            fill="#FFFFFF" 
            stroke="#FFFFFF"
            strokeWidth={1}
            fillOpacity={0.8}
            radius={[4, 4, 0, 0]}
            barSize={12}
          />
          <Bar 
            dataKey="realizado" 
            name="Realizado" 
            fill="#00AB16" 
            radius={[4, 4, 0, 0]}
            barSize={12}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
